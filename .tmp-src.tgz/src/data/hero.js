// ---------------------------------------------------------------------------
// HERO BANNER SLIDES: this is the file to edit to change the banner.
//
//  * Add, remove or reorder slides freely: the slider, dots and thumbnails adapt.
//  * `image` can be any of:
//      - a Cloudinary public ID      'topstea/hero-1'
//      - a full image URL            'https://res.cloudinary.com/.../photo.jpg'
//      - a local file in /public     '/images/hero-1.jpg'
// ---------------------------------------------------------------------------

export const heroSlides = [
  {
    image: 'https://res.cloudinary.com/ddj0k8gdw/image/upload/v1794983355/Top-Stea-images/Picture6_x7px4c.png',
    alt: 'MEPF engineers on site',
    title: 'We are specialists in MEPF installation',
    text: 'TOP-STEA delivers qualified technical manpower, experienced site supervision and specialist Mechanical, Electrical, Plumbing and Fire Protection teams for new-build and renovation projects.',
    cta: { label: 'Read More', to: '/about' },
  },
  {
    image: 'https://res.cloudinary.com/ddj0k8gdw/image/upload/v1794984825/construcao_wqkg3g.jpg',
    alt: 'Rapid mobilisation of technical teams',
    title: 'We mobilise fast and deliver on programme',
    text: 'Supervisors and foremen first, full workforce second, deployed incrementally to match your programme.',
    cta: { label: 'Our Methodology', to: '/methodology' },
  },
  {
    image: 'https://res.cloudinary.com/ddj0k8gdw/image/upload/v1794984671/professional-black-african-engineer-service-heavy-machine-in-heavy-industry-factory-photo_q7sjsh.jpg',
    alt: 'Flexible MEPF project delivery',
    title: 'We deliver flexible MEPF solutions, end to end',
    text: 'Choose manpower supply or full project execution. One accountable team for quality, safety and productivity.',
    cta: { label: 'Engagement Models', to: '/engagement' },
  },
]
